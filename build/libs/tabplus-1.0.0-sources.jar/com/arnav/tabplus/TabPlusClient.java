package com.arnav.tabplus;

import com.arnav.tabplus.screen.ProfileScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_310;
import net.minecraft.class_640;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class TabPlusClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("tabplus");

    @Override
    public void onInitializeClient() {
        // force keybinding registration
        TabPlusKeys.NOTE.getClass();

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String server = resolveServerAddress(client);
            PlayerDataStore.getInstance().load(server);
            TabFilter.getInstance().clear();
            LOGGER.info("Tab+ loaded data for server: {}", server);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            TabFilter.getInstance().clear();
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        LOGGER.info("Tab+ initialized.");
    }

    private void onTick(class_310 client) {
        if (client.field_1755 != null) return;
        if (!client.field_1690.field_1907.method_1434()) return;
        if (client.method_1562() == null) return;

        var players = new java.util.ArrayList<>(client.method_1562().method_45732());
        if (players.isEmpty()) return;

        int idx = Math.min(TabFilter.getInstance().getSelectedIndex(), players.size() - 1);
        class_640 target = players.get(idx);

        if (TabFilter.getInstance().consumeOpenProfile()) {
            client.method_1507(new ProfileScreen(
                target.method_2966().getId(),
                target.method_2966().getName()
            ));
            return;
        }

        while (TabPlusKeys.NOTE.method_1436()) {
            client.method_1507(new ProfileScreen(
                target.method_2966().getId(),
                target.method_2966().getName()
            ));
        }

        while (TabPlusKeys.TAG.method_1436()) {
            var uuid = target.method_2966().getId();
            var store = PlayerDataStore.getInstance();
            var data = store.get(uuid);
            data.tag = data.tag.next();
            store.set(uuid, data);
        }
    }

    private static String resolveServerAddress(class_310 client) {
        if (client.method_1542()) return "singleplayer";
        var server = client.method_1558();
        if (server != null) return server.field_3761;
        return "unknown";
    }
}
