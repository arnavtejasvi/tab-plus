package com.arnav.tabplus.screen;

import com.arnav.tabplus.PlayerData;
import com.arnav.tabplus.PlayerDataStore;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class NoteEditScreen extends class_437 {
    private final UUID playerUuid;
    private final String playerName;
    private class_342 noteField;

    public NoteEditScreen(UUID playerUuid, String playerName) {
        super(class_2561.method_43471("tabplus.note.title"));
        this.playerUuid = playerUuid;
        this.playerName = playerName;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;

        noteField = new class_342(field_22793, centerX - 100, centerY - 10, 200, 20,
            class_2561.method_43471("tabplus.note.placeholder"));
        noteField.method_1880(120);
        noteField.method_1852(PlayerDataStore.getInstance().get(playerUuid).note);
        noteField.method_25365(true);
        method_37063(noteField);

        method_37063(class_4185.method_46430(class_2561.method_43471("tabplus.note.save"), btn -> save())
            .method_46434(centerX - 105, centerY + 16, 100, 20)
            .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("tabplus.note.clear"), btn -> {
            noteField.method_1852("");
            save();
        }).method_46434(centerX + 5, centerY + 16, 100, 20).method_46431());
    }

    private void save() {
        PlayerData data = PlayerDataStore.getInstance().get(playerUuid);
        data.note = noteField.method_1882().trim();
        PlayerDataStore.getInstance().set(playerUuid, data);
        method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;
        context.method_27534(field_22793, field_22785, centerX, centerY - 30, 0xFFFFFF);
        context.method_27534(field_22793,
            class_2561.method_43470(playerName), centerX, centerY - 20, 0xAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter / numpad enter
            save();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
