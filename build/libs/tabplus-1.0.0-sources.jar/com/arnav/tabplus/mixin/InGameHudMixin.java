package com.arnav.tabplus.mixin;

import com.arnav.tabplus.TabOverlayRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_8646;
import net.minecraft.class_9779;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Shadow @Final private class_310 client;
    @Shadow private class_355 playerListHud;

    @Inject(method = "renderPlayerList", at = @At("HEAD"), cancellable = true)
    private void onRenderPlayerList(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (!client.field_1690.field_1907.method_1434()) return;

        class_269 scoreboard = client.field_1687.method_8428();
        @Nullable class_266 objective = scoreboard.method_1189(class_8646.field_45156);

        PlayerListHudAccessor accessor = (PlayerListHudAccessor) playerListHud;
        @Nullable class_2561 header = accessor.tabplus_getHeader();
        @Nullable class_2561 footer = accessor.tabplus_getFooter();

        playerListHud.method_1921(true);
        TabOverlayRenderer.render(context, context.method_51421(), scoreboard, objective, header, footer);
        ci.cancel();
    }
}
