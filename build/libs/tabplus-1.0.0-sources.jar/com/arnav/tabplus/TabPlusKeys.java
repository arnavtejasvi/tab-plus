package com.arnav.tabplus;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class TabPlusKeys {
    public static final class_304 NOTE = KeyBindingHelper.registerKeyBinding(new class_304(
        "key.tabplus.note",
        GLFW.GLFW_KEY_N,
        "key.categories.tabplus"
    ));

    public static final class_304 TAG = KeyBindingHelper.registerKeyBinding(new class_304(
        "key.tabplus.tag",
        GLFW.GLFW_KEY_T,
        "key.categories.tabplus"
    ));

    private TabPlusKeys() {}
}
