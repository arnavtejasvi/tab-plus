package com.arnav.tabplus.mixin;

import com.arnav.tabplus.TabFilter;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public abstract class KeyboardMixin {
    @Shadow @Final private class_310 client;

    @Inject(method = "onChar", at = @At("HEAD"), cancellable = true)
    private void onChar(long window, int codepoint, int modifiers, CallbackInfo ci) {
        if (client.field_1755 != null) return;
        if (!client.field_1690.field_1907.method_1434()) return;
        if (com.arnav.tabplus.TabPlusKeys.NOTE.method_1434()) return;
        if (com.arnav.tabplus.TabPlusKeys.TAG.method_1434()) return;
        if (codepoint >= 32 && codepoint < 127) {
            TabFilter.getInstance().appendChar((char) codepoint);
            ci.cancel();
        }
    }

    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (client.field_1755 != null) return;
        if (!client.field_1690.field_1907.method_1434()) return;
        if (action == GLFW.GLFW_PRESS || action == GLFW.GLFW_REPEAT) {
            switch (key) {
                case GLFW.GLFW_KEY_BACKSPACE -> { TabFilter.getInstance().backspace(); ci.cancel(); }
                case GLFW.GLFW_KEY_ESCAPE    -> { TabFilter.getInstance().clear();     ci.cancel(); }
                case GLFW.GLFW_KEY_UP        -> { TabFilter.getInstance().moveSelection(-1); ci.cancel(); }
                case GLFW.GLFW_KEY_DOWN      -> { TabFilter.getInstance().moveSelection(1);  ci.cancel(); }
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                    TabFilter.getInstance().requestOpenProfile();
                    ci.cancel();
                }
            }
        }
    }
}
