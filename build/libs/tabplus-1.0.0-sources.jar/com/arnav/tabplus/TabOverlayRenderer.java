package com.arnav.tabplus;

import org.jetbrains.annotations.Nullable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_8685;

public class TabOverlayRenderer {

    private static final Logger LOGGER = LoggerFactory.getLogger("tabplus");
    private static final int ROW_HEIGHT = 10;
    private static final int HEAD_SIZE = 8;
    private static final int HEAD_MARGIN = 3;
    private static final int PING_WIDTH = 36;
    private static final int COLUMN_GAP = 6;
    private static final int MAX_COLUMNS = 4;
    private static final int MAX_ROWS = 20;
    private static final int PADDING = 4;

    private static final int BG_COLOR     = 0x99000000;
    private static final int HOVER_COLOR  = 0x33FFFFFF;
    private static final int WHITE        = 0xFFFFFF;
    private static final int GRAY         = 0xAAAAAA;

    private static final Comparator<class_640> PLAYER_ORDER = Comparator
        .comparing((class_640 e) -> {
            var team = e.method_2955();
            return team != null ? team.method_1197() : "";
        })
        .thenComparing(e -> e.method_2966().getName().toLowerCase());

    private TabOverlayRenderer() {}

    public static void render(class_332 context, int screenWidth,
                              class_269 scoreboard, @Nullable class_266 objective,
                              @Nullable class_2561 header, @Nullable class_2561 footer) {
        class_310 client = class_310.method_1551();
        class_634 handler = client.method_1562();
        if (handler == null) { LOGGER.info("[Tab+] handler null"); return; }

        class_327 tr = client.field_1772;

        // --- collect + filter players ---
        String filterStr = TabFilter.getInstance().getFilter().toLowerCase();
        LOGGER.info("[Tab+] render called, playerCount={}", handler.method_45732().size());
        List<class_640> players = handler.method_45732().stream()
            .sorted(PLAYER_ORDER)
            .filter(e -> filterStr.isEmpty() || matchesFilter(e, filterStr))
            .limit((long) MAX_COLUMNS * MAX_ROWS)
            .toList();

        if (players.isEmpty() && filterStr.isEmpty()) return;

        TabFilter.getInstance().setListSize(players.size());
        int selectedIndex = TabFilter.getInstance().getSelectedIndex();

        // --- layout ---
        int columnCount = Math.max(1, (players.size() + MAX_ROWS - 1) / MAX_ROWS);
        int rowCount    = columnCount == 0 ? 0 : (players.size() + columnCount - 1) / columnCount;

        int maxNameWidth = 0;
        for (class_640 e : players) {
            maxNameWidth = Math.max(maxNameWidth, tr.method_27525(getDisplayText(e)));
        }
        int entryWidth = HEAD_SIZE + HEAD_MARGIN + maxNameWidth + HEAD_MARGIN + PING_WIDTH;
        entryWidth = Math.max(entryWidth, 80);

        int totalWidth  = entryWidth * columnCount + COLUMN_GAP * (columnCount - 1);
        int totalHeight = rowCount * ROW_HEIGHT;

        int startX = (screenWidth - totalWidth) / 2;
        int startY = 10;

        // --- header ---
        if (header != null) {
            int hw = tr.method_27525(header);
            int hx = (screenWidth - hw - PADDING * 2) / 2;
            context.method_25294(hx, startY - PADDING, hx + hw + PADDING * 2, startY + tr.field_2000 + PADDING, BG_COLOR);
            context.method_51439(tr, header, hx + PADDING, startY, WHITE, true);
            startY += tr.field_2000 + PADDING * 2 + 2;
        }

        // --- player list background ---
        context.method_25294(startX - PADDING, startY - PADDING,
            startX + totalWidth + PADDING, startY + totalHeight + PADDING, BG_COLOR);

        // --- draw players ---
        for (int i = 0; i < players.size(); i++) {
            int col = i / MAX_ROWS;
            int row = i % MAX_ROWS;
            int x   = startX + col * (entryWidth + COLUMN_GAP);
            int y   = startY + row * ROW_HEIGHT;

            class_640 entry = players.get(i);
            UUID uuid = entry.method_2966().getId();
            PlayerData data = PlayerDataStore.getInstance().get(uuid);

            if (i == selectedIndex) {
                context.method_25294(x - 1, y, x + entryWidth + 1, y + ROW_HEIGHT, HOVER_COLOR);
            }

            // player head
            class_8685 skin = entry.method_52810();
            class_2960 skinTex = skin.comp_1626();
            context.method_25293(skinTex, x, y + 1, HEAD_SIZE, HEAD_SIZE, 8.0f, 8.0f, 8, 8, 64, 64);
            // hat layer
            context.method_25293(skinTex, x, y + 1, HEAD_SIZE, HEAD_SIZE, 40.0f, 8.0f, 8, 8, 64, 64);

            // name
            int nameColor = data.tag != RelationshipTag.NONE ? data.tag.color : WHITE;
            class_2561 displayText = getDisplayText(entry);
            context.method_51439(tr, displayText, x + HEAD_SIZE + HEAD_MARGIN, y + 1, nameColor, false);

            // tag dot (small colored square if tagged)
            if (data.tag != RelationshipTag.NONE) {
                int dotX = x + HEAD_SIZE + HEAD_MARGIN - 3;
                context.method_25294(dotX, y + 3, dotX + 2, y + 5, data.tag.color | 0xFF000000);
            }

            // ping
            int ping = entry.method_2959();
            String pingStr = ping < 0 ? "?" : ping + "ms";
            int pingColor = pingColor(ping);
            context.method_51433(tr, pingStr, x + entryWidth - tr.method_1727(pingStr), y + 1, pingColor, false);
        }

        // --- filter bar ---
        if (!filterStr.isEmpty() || players.isEmpty()) {
            int filterY = startY + totalHeight + PADDING + 2;
            String filterLabel = "Filter: " + TabFilter.getInstance().getFilter() + "_";
            int fw = tr.method_1727(filterLabel);
            int fx = (screenWidth - fw - PADDING * 2) / 2;
            context.method_25294(fx, filterY - 2, fx + fw + PADDING * 2, filterY + tr.field_2000 + 2, BG_COLOR);
            context.method_51433(tr, filterLabel, fx + PADDING, filterY, 0xFFDD44, false);
        }

        // --- footer ---
        if (footer != null) {
            int footerY = startY + totalHeight + PADDING + (filterStr.isEmpty() ? 2 : tr.field_2000 + 8);
            int fw = tr.method_27525(footer);
            int fx = (screenWidth - fw - PADDING * 2) / 2;
            context.method_25294(fx, footerY - PADDING, fx + fw + PADDING * 2, footerY + tr.field_2000 + PADDING, BG_COLOR);
            context.method_51439(tr, footer, fx + PADDING, footerY, WHITE, true);
        }

    }

    private static class_2561 getDisplayText(class_640 entry) {
        class_2561 display = entry.method_2971();
        if (display != null) return display;
        return class_2561.method_43470(entry.method_2966().getName());
    }

    private static boolean matchesFilter(class_640 entry, String filter) {
        String name = entry.method_2966().getName().toLowerCase();
        if (name.contains(filter)) return true;
        UUID uuid = entry.method_2966().getId();
        PlayerData data = PlayerDataStore.getInstance().get(uuid);
        if (data.tag != RelationshipTag.NONE && data.tag.label.toLowerCase().contains(filter)) return true;
        return false;
    }

    private static int pingColor(int ping) {
        if (ping < 0)   return 0xAAAAAA;
        if (ping < 150) return 0x55FF55;
        if (ping < 300) return 0xFFFF55;
        if (ping < 600) return 0xFF5555;
        return 0xAA0000;
    }
}
