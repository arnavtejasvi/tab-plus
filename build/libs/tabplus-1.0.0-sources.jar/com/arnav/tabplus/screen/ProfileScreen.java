package com.arnav.tabplus.screen;

import com.arnav.tabplus.PlayerData;
import com.arnav.tabplus.PlayerDataStore;
import com.arnav.tabplus.RelationshipTag;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ProfileScreen extends class_437 {
    private final UUID playerUuid;
    private final String playerName;
    private PlayerData data;
    private class_342 noteField;

    private static final int ROW_HEIGHT = 24;

    public ProfileScreen(UUID playerUuid, String playerName) {
        super(class_2561.method_43470("Profile"));
        this.playerUuid = playerUuid;
        this.playerName = playerName;
    }

    @Override
    protected void method_25426() {
        data = PlayerDataStore.getInstance().get(playerUuid);

        int cx = field_22789 / 2;
        int topY = field_22790 / 2 - 50;

        // tag arrows — row 0
        int tagRowY = topY + ROW_HEIGHT * 2;
        method_37063(class_4185.method_46430(class_2561.method_43470("<"), btn -> cycleTag(-1))
            .method_46434(cx - 60, tagRowY, 20, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470(">"), btn -> cycleTag(1))
            .method_46434(cx + 40, tagRowY, 20, 20).method_46431());

        // note field — row 1
        int noteRowY = topY + ROW_HEIGHT * 4;
        noteField = new class_342(field_22793, cx - 80, noteRowY, 160, 20,
            class_2561.method_43470("Note..."));
        noteField.method_1880(120);
        noteField.method_1852(data.note);
        noteField.method_25365(true);
        method_37063(noteField);

        // done button
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> save())
            .method_46434(cx - 30, topY + ROW_HEIGHT * 6, 60, 20).method_46431());
    }

    private void cycleTag(int dir) {
        RelationshipTag[] vals = RelationshipTag.values();
        data.tag = vals[Math.floorMod(data.tag.ordinal() + dir, vals.length)];
    }

    private void save() {
        data.note = noteField.method_1882().trim();
        PlayerDataStore.getInstance().set(playerUuid, data);
        method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        int cx = field_22789 / 2;
        int topY = field_22790 / 2 - 50;

        // player name header
        context.method_27534(field_22793, class_2561.method_43470(playerName), cx, topY, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("— profile —"), cx, topY + 10, 0x666666);

        // tag section label
        int tagRowY = topY + ROW_HEIGHT * 2;
        context.method_27534(field_22793, class_2561.method_43470("Tag"), cx, tagRowY - 10, 0xAAAAAA);

        // tag name in its color, between the arrows
        String tagLabel = data.tag == RelationshipTag.NONE ? "None" : data.tag.label;
        int tagColor = data.tag == RelationshipTag.NONE ? 0xAAAAAA : data.tag.color;
        context.method_27534(field_22793, class_2561.method_43470(tagLabel), cx, tagRowY + 6, tagColor);

        // note label
        int noteRowY = topY + ROW_HEIGHT * 4;
        context.method_27534(field_22793, class_2561.method_43470("Note"), cx, noteRowY - 10, 0xAAAAAA);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { save(); return true; }
        if (keyCode == 256) { method_25419(); return true; }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
