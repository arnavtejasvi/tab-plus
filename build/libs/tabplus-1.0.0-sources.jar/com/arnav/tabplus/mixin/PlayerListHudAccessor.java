package com.arnav.tabplus.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_355;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_355.class)
public interface PlayerListHudAccessor {
    @Accessor("header")
    @Nullable class_2561 tabplus_getHeader();

    @Accessor("footer")
    @Nullable class_2561 tabplus_getFooter();
}
